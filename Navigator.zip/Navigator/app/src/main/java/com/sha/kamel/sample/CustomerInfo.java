package com.sha.kamel.sample;

import org.parceler.Parcel;

/**
 * Created by Sha on 11/10/17.
 */

@Parcel
public class CustomerInfo {
     String name = "Shaban Kamel";
     int age = 28;
     String mobile = "01020485203";
     String area = "Cairo";

    public CustomerInfo setName(String name) {
        this.name = name;
        return this;
    }

    public CustomerInfo setAge(int age) {
        this.age = age;
        return this;
    }

    public CustomerInfo setMobile(String mobile) {
        this.mobile = mobile;
        return this;
    }

    public CustomerInfo setArea(String area) {
        this.area = area;
        return this;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getMobile() {
        return mobile;
    }

    public String getArea() {
        return area;
    }
}
