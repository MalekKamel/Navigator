package com.sha.kamel.sample.ui;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.sha.kamel.navigator.FragmentNavigator;
import com.sha.kamel.sample.CustomerInfo;
import com.sha.kamel.sample.R;

import org.parceler.Parcels;


/**
 * Created by Sha on 11/11/17.
 */

public class ClientInfoDialogFragment extends DialogFragment{

    private TextView tv;
    private TextView tv_name;
    private TextView tv_age;
    private TextView tv_mobile;

    private CustomerInfo customerInfo;

    public static ClientInfoDialogFragment newInstance(CustomerInfo customerInfo) {
        ClientInfoDialogFragment fragment = new ClientInfoDialogFragment();
        fragment.customerInfo = customerInfo;
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_dialog_client_info,container,false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        tv = getView().findViewById(R.id.tv);
        tv_name = getView().findViewById(R.id.tv_name);
        tv_age = getView().findViewById(R.id.tv_age);
        tv_mobile = getView().findViewById(R.id.tv_mobile);

        setText("This is " + getClass().getSimpleName());

        if (getArguments() != null){
            CustomerInfo info = Parcels.unwrap(getArguments().getParcelable(FragmentNavigator.DEFAULT_PARCELABLE_NAME));
            if (info != null)
                customerInfo = info;
        }

        tv_name.setText(customerInfo.getName());
        tv_age.setText(String.valueOf(customerInfo.getAge()));
        tv_mobile.setText(customerInfo.getMobile());
    }

    protected void setText(String text){
        tv.setText(text);
    }

    protected void addText(String text){
        String s = tv.getText() + "\n" + text;
        tv.setText(s);
    }
}
