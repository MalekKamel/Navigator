package com.sha.kamel.sample.ui;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.sha.kamel.navigator.FragmentNavigator;
import com.sha.kamel.sample.R;

public class FragmentDemoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment_demo);

        findViewById(R.id.btnReplaceFragment).setOnClickListener(v ->
                new FragmentNavigator(this).replace(
                        ExampleFragment.newInstance(),
                        true
                )
        );

        findViewById(R.id.btnAddFragment).setOnClickListener(v ->
                new FragmentNavigator(this, R.id.mainFrame).add(
                        ExampleFragment.newInstance(),
                        true
                )
        );

        findViewById(R.id.btnAddFragmentDelayed).setOnClickListener(v ->
                new FragmentNavigator(this).addDelayed(
                        ExampleFragment.newInstance(),
                        true,
                        2000
                )
        );

        findViewById(R.id.btnReplaceFragmentDelayed).setOnClickListener(v ->
                new FragmentNavigator(this).replaceDelayed(
                        ExampleFragment.newInstance(),
                        true,
                        2000
                )
        );
    }



}
