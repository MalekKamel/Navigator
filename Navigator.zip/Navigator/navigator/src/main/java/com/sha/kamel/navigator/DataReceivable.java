package com.sha.kamel.navigator;

/**
 * Created by Sha on 11/11/17.
 */

public interface DataReceivable<T> {

    void receivedData(T data);

}
