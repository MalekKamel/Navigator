package com.sha.kamel.navigator;

/**
 * Created by Sha on 10/2/17.
 */

public interface Procedure {
    void call();
}
